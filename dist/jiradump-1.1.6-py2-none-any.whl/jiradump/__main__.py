#!/usr/bin/env python

"""__main__.py - Convenience stub to run the main method when
executed with python's -m option.

"""

import jiradump
jiradump.main()
